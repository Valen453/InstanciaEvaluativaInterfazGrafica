/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package instanciaevaluativa1interfaz;

/**
 *
 * @author PalomaOttonello
 */
public interface Evaluable {
    String getCondicion();
    double getPromedio();
    boolean estaAprobada();

    default void mostrarEstadoAcademico() {
        //s= string n=salto de linea
        System.out.printf("Condición: %s%n", getCondicion());
        //%.2f%n" es para que lea numeros decimales
        System.out.printf("Promedio:  %.2f%n", getPromedio());
        System.out.println("Aprobada: " + (estaAprobada() ? "Sí" : "No"));
    }
}


