/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package instanciaevaluativa1interfaz;

/**
 *
 * @author PalomaOttonello
 */
public interface Consultable {
    void mostrarResumen();
    
}
