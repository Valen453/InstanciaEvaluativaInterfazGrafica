/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package instanciaevaluativa1interfaz;
import java.util.ArrayList; // 
/**
 *
 * @author PalomaOttonello
 */

 public class Estudiante extends PersonaAcademica implements Consultable {
    
    private String carrera;
    private int anioIngreso;
    private ArrayList<InscripcionMateria> materias;
    

    
   
    public Estudiante(String nombre, String legajo, String carrera, int anioIngreso) {
    super(nombre, legajo);
    this.carrera     = carrera;
    this.anioIngreso = anioIngreso;
    this.materias    = new ArrayList<>();
}


    public void inscribirse(Materia m) {
        if (getInscripcion(m.getCodigo()) == null) {
            materias.add(new InscripcionMateria(m));
            System.out.println("Inscripto a: " + m.getNombre());
        } else {
            System.out.println("Ya estas inscripto a esa materia.");
        }
    }
 
   public void darDeBaja(String codigoMateria) {
    InscripcionMateria insc = getInscripcion(codigoMateria);
    if (insc != null) {
        materias.remove(insc);
        System.out.println("Materia eliminada.");
    } else {
        System.out.println("No se encontro ninguna materia con ese codigo.");
    }
}  
   

//SOBRECARGAS
    // Sobrecarga I: por codigo exacto
    public InscripcionMateria getInscripcion(String codigoMateria) {
        for (InscripcionMateria i : materias) {
            if (i.getMateria().getCodigo().equalsIgnoreCase(codigoMateria)) return i;
        }
        return null;
    }
 
    // Sobrecarga II: buscar por cuatrimestre (devuelve todas las de ese cuatrimestre)
    public ArrayList<InscripcionMateria> getInscripcion(int cuatrimestre) {
        ArrayList<InscripcionMateria> resultado = new ArrayList<>();
        for (InscripcionMateria i : materias) {
            if (i.getMateria().getCuatrimestre() == cuatrimestre) resultado.add(i);
        }
        return resultado;
    }
 
    // Busqueda x nombre
    public ArrayList<InscripcionMateria> buscarPorNombre(String fragmento) {
        ArrayList<InscripcionMateria> resultado = new ArrayList<>();
        for (InscripcionMateria i : materias) {
            if (i.getMateria().getNombre().toLowerCase()
                    .contains(fragmento.toLowerCase())) resultado.add(i);
        }
        return resultado;
    }
 
    // Promedios
    public double getPromedioGeneral() {
        if (materias.isEmpty()) return 0;
        double suma = 0;
        int cont = 0;
        for (InscripcionMateria i : materias) {
            double p = i.getPromedio();
            if (p > 0) { suma += p; cont++; }
        }
        return cont == 0 ? 0 : suma / cont;
    }
 
    public ArrayList<InscripcionMateria> getMateriasCriticas() {
        ArrayList<InscripcionMateria> criticas = new ArrayList<>();
        for (InscripcionMateria i : materias) {
            double a = i.getPorcentajeAsistencia();
            if (a >= 75 && a <= 85) criticas.add(i);
        }
        return criticas;
    }
    
    public ArrayList<InscripcionMateria> getMateriasCursando() { return materias; }
    //public ArrayList<InscripcionMateria> getMaterias() { return materias; }
 
   
    public String getCarrera() { return carrera; }
    public int getAnioIngreso() { return anioIngreso; }
 
    // Sobreescribe el metodo de PersonaAcademica
    @Override
    public void mostrarResumen() {
        System.out.println("PERFIL DE ALUMNO");
        System.out.println("Nombre:   " + getNombre());
        System.out.println("Legajo:   " + getLegajo());
        System.out.println("Carrera:  " + carrera);
        System.out.println("Ingreso:  " + anioIngreso);
        System.out.println("Materias: " + materias.size());
    }
 }

    